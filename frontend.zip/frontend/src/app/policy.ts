export class Policy {
    id: any;
    number: any;
    amount: any;
}